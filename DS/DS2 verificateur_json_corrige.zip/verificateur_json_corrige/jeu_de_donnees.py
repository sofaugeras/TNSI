"""
Vérificateur JSON

Evaluation sur machine en terminale NSI terminale concernant les chapitres :
  * Programmation Orientée Objet
  * Sutructures des données : piles/files
  * Tests unitaires avec assert
"""


# Liste des fichiers JSON à analyser
les_fichiers_json = [
    "fichiers/test00.json",     # correct
    "fichiers/test01.json",     # erreur accolades
    "fichiers/test02.json",     # erreur crochet
    "fichiers/test03.json",     # correct
    "fichiers/test04.json"      # correct
]

# Liste des chaînes de caractères correctes
chaines_correctes = [
    "{}",
    "{}{}",
    "{{{}}}",
    "{{{}{{{}}}}}",
    "{{{{}}{{{}}}}}",
    "[]",
    "[][]",
    "[[[]][]]",
    "{[[[{}]]{[]}]}",
    "[{}]{}{[{}{}]{}}",
]

# Liste des chaînes de caractères incorrectes
chaines_incorrectes = [
    "{}{",
    "{}}",
    "{{}}}",
    "{{{}{{{}}}}",
    "{{{{{}}{{{}}}}}",
    "[{]}",
    "[]{]}",
    "[[{]][]]",
    "{[[[{}]]{[}}]}",
    "[{}]{}{[{}{[]{}}",
]