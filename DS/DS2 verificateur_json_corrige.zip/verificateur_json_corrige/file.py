"""
File basée sur une liste chaînée

Evaluation sur machine en terminale NSI terminale concernant les chapitres :
  * Programmation Orientée Objet
  * Sutructures des données : piles/files
  * Tests unitaires avec assert
"""

# Librairie utilisée
from noeud import *


class File:
    """Classe représentant une file (FIFO) basée sur une liste chaînée"""

    def __init__(self):
        """Initialise une file avec un noeud vide et la nomme

        Parameters:
            nom (string): nom de la pile
        """
        self.tete = None
        self.queue = None

    def etre_vide(self):
        """Permet de savoir si la file est vide ou pas

        Returns:
            bool: True si la pile est vide, False sinon
        """
        if self.tete is None:
            return True
        else:
            return False
        
    def ajouter(self, donnee):
        """Ajoute un élément (donnee) à la fin de la file

        Parameters:
            donnee (Any): données ajoutée à la fin de la file
        """
        nouveau_noeud = Noeud(donnee)
        if self.etre_vide():
            self.tete = nouveau_noeud
            self.queue = nouveau_noeud
        else:
            self.queue.set_precedent(nouveau_noeud)
            self.queue = nouveau_noeud

    def retirer(self):
        """Supprime un élément en tête de file et permet d'accèder à la donnée qu'il contient

        Returns:
            (Any): donnée qui était en tête de la file
        """
        if self.etre_vide():
            print("La file est vide !\n")
            return
        else:
            donnee = self.tete.get_donnee()
            self.tete = self.tete.get_precedent()
            return donnee

    def afficher(self):
        """Affiche une file et tous ses éléments sous la forme :

        File : tête --> [...] [...] [...] <-- queue
        """
        if self.etre_vide():
            print("La file est vide !")
            return
        else:
            print("File : tête --> ", end="")
            n = self.tete
            while n is not None:
                print(f"[{n.get_donnee()}] ", end="")
                n = n.get_precedent()
            print("<-- queue")



