"""
Vérificateur JSON

Evaluation sur machine en terminale NSI terminale concernant les chapitres :
  * Programmation Orientée Objet
  * Sutructures des données : piles/files
  * Tests unitaires avec assert
"""

from pile import Pile


class Verificateur:
    """Classe représentant l'outil de vérification de code JSON"""

    def __init__(self):
        """Initialise le vérificateur"""
        pass


    def lire_contenu_fichier(self, chemin_fichier):
        """Lit le contenu d'un fichier JSON

        Parameters:
            chemin_fichier (string) : chemin vers le fichier JSON à lire

        Returns:
            (string) : le contenu du fichier sous la forme d'une chaîne de caractères
        """
        # Ajout de : encoding='utf-8' sinon probleme de lecture du fichier test04.json
        with open(chemin_fichier, 'r', encoding='utf-8') as fichier_a_analyser:
            # Lecture de toutes les lignes qui seront stockées dans un tableau
            contenu = fichier_a_analyser.read()

            # Fermeture du fichier
            fichier_a_analyser.close()

            # On retourne le contenu du fichier
            return contenu


    def verifier_accolades(self, chaine):
        """Analyse une chaîne de caractère pour vérifier si les accolades sont correctes

        Parameters:
            chaine (string) : chaine de caractères à analyser

        Returns:
            (boolean) : True si la chaîne est correcte, False sinon
        """
        # Création d"un pile pour assurer les vérifications
        pile_verification = Pile()

        # Analyse et vérification des accolades dans la chaîne de caractères
        for caractere in chaine:
            if caractere == "{":
                pile_verification.empiler(caractere)
            if caractere == "}":
                if pile_verification.etre_vide():
                    return False
                if pile_verification.depiler() != "{":
                    return False

        # Si la pile n'est pas vide à la fin, c'est qu'il y a un problème
        return pile_verification.etre_vide()


    def verifier_accolades_et_crochets(self, chaine):
        """Analyse une chaîne de caractère pour vérifier si les accolades et crochets corrects

        Parameters:
            chaine (string) : chaine de caractères à analyser

        Returns:
            (boolean) : True si la chaîne est correcte, False sinon
        """
        # Création d"un pile pour assurer les vérifications
        pile_verification = Pile()

        # Analyse et vérification des accolades dans la chaîne de caractères
        for caractere in chaine:
            if caractere == "{" or caractere == "[":
                pile_verification.empiler(caractere)
            if caractere == "}":
                if pile_verification.etre_vide():
                    return False
                if pile_verification.depiler() != "{":
                    return False
            if caractere == "]":
                if pile_verification.etre_vide():
                    return False
                if pile_verification.depiler() != "[":
                    return False

        # Si la pile n'est pas vide à la fin, c'est qu'il y a un problème
        return pile_verification.etre_vide()


    def verifier_fichier(self, fichier_json):
        """Vérifie les accolades et crochets d'un fichier JSON

        Parameters:
            fichier_json (string) : chemin vers le fichier JSON à vérifier

        Returns:
            (boolean) : True si le fichier est correct, False sinon
        """
        # Ouverture et lecture du fichier JSON
        contenu_json = self.lire_contenu_fichier(fichier_json)

        # Vérification des accolades et crochets dans le contenu JSON
        return self.verifier_accolades_et_crochets(contenu_json)