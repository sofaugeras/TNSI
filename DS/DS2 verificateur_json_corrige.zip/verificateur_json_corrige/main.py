"""
Vérificateur JSON

Evaluation sur machine en terminale NSI terminale concernant les chapitres :
  * Programmation Orientée Objet
  * Sutructures des données : piles/files
  * Tests unitaires avec assert
"""

# Importations
from verificateur import Verificateur
from jeu_de_donnees import *



# Exercice 2.3 : utilisation de la méthode verifier_accolades() toute seule
v23 = Verificateur()
print(v23.verifier_accolades("{}}"))

for chaine in chaines_correctes:
    print(f"{chaine} => {v23.verifier_accolades(chaine)}")
for chaine in chaines_incorrectes:
    print(f"{chaine} => {v23.verifier_accolades(chaine)}")


# Exercice 2.4 : utilisation de la méthode verifier_accolades_et_crochets()
v24 = Verificateur()
print(v24.verifier_accolades_et_crochets("[]{}"))

for chaine_ok in chaines_correctes:
    print(f"{chaine_ok} => {v24.verifier_accolades_et_crochets(chaine_ok)}")
for chaine_bis in chaines_incorrectes:
    print(f"{chaine_bis} => {v24.verifier_accolades_et_crochets(chaine_bis)}")


# Exercice 2.5 : vérification accolades et crochets
v25 = Verificateur()
print(v25.verifier_accolades_et_crochets("{[]}"))

for chaine in chaines_correctes:
    print(f"{chaine} => {v25.verifier_accolades_et_crochets(chaine)}")
for chaine in chaines_incorrectes:
    print(f"{chaine} => {v25.verifier_accolades_et_crochets(chaine)}")


# Exercice 2.7 : utilisation sur un fichier JSON
v27 = Verificateur()
fichier_json = "fichiers/test00.json"
print(f"fichiers/test00.json => {v27.verifier_fichier(fichier_json)}")


# Exercice 2.8 : utilisation sur un ensemble de fichiers JSON
v28 = Verificateur()
for un_fichier_json in les_fichiers_json:
    print(f"{un_fichier_json} => {v28.verifier_fichier(un_fichier_json)}")



