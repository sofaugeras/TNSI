"""
Vérificateur JSON

Evaluation sur machine en terminale NSI terminale concernant les chapitres :
  * Programmation Orientée Objet
  * Sutructures des données : piles/files
  * Tests unitaires avec assert
"""

# Importations
from verificateur import *
from jeu_de_donnees import *


# Exercice 2.4 : utilisation des assertions pour valider les tests unitaires
v24 = Verificateur()
for chaine in chaines_correctes:
    assert v24.verifier_accolades(chaine) == True, f"{chaine} devrait être correcte"
for chaine in chaines_incorrectes:
    assert v24.verifier_accolades(chaine) == False, f"{chaine} devrait être incorrecte"


# Exercice 2.6 : utilisation des assertions pour valider les tests unitaires
v26 = Verificateur()
for chaine in chaines_correctes:
    assert v26.verifier_accolades_et_crochets(chaine) == True, f"{chaine} devrait être correcte"
for chaine in chaines_incorrectes:
    assert v26.verifier_accolades_et_crochets(chaine) == False, f"{chaine} devrait être incorrecte"