"""
Vérificateur JSON

Evaluation sur machine en terminale NSI terminale concernant les chapitres :
  * Programmation Orientée Objet
  * Sutructures des données : piles/files
  * Tests unitaires avec assert
"""

from noeud import *


class Pile:
    """Classe représentant une pile (LIFO) basée sur une implémentation avec tableau"""


    def __init__(self):
        """Initialise une pile avec un tableau vide
        """
        self.donnees = []


    def etre_vide(self):
        """Permet de savoir si la pile est vide ou pas

        Returns:
            bool: True si la pile est vide, False sinon
        """
        if len(self.donnees) == 0:
            return True
        else:
            return False


    def empiler(self, donnee):
        """Ajoute un élément (donnee) sur le dessus de la pile

        Parameters:
            donnee (Any): donnée à ajouter sur la pile.
        """
        self.donnees.append(donnee)


    def depiler(self):
        """Supprime et retourne l'élément au sommet de la pile

        Returns:
           donnee (Any): donnée qui était au sommet de la pile, None si la pile est vide
        """
        if self.etre_vide():
            return None
        else:
            return self.donnees.pop()


    def afficher(self):
        """Affiche une pile et tous ses éléments
        """
        print(self.donnees)


# Tests et mise au point de la classe Pile
if __name__ == "__main__":
    une_pile = Pile()
    une_pile.afficher()
    print(une_pile.etre_vide())
    une_pile.empiler(1)
    une_pile.afficher()
    une_pile.empiler(2)
    une_pile.afficher()
    une_pile.empiler(3)
    une_pile.afficher()
    print(une_pile.etre_vide())
    print(une_pile.depiler())
    une_pile.afficher()
    print(une_pile.depiler())
    une_pile.afficher()
    print(une_pile.depiler())
    une_pile.afficher()
    print(une_pile.etre_vide())

