"""
File basée sur une liste chaînée

Evaluation sur machine en terminale NSI terminale concernant les chapitres :
  * Programmation Orientée Objet
  * Sutructures des données : piles/files
  * Tests unitaires avec assert
"""

class Noeud:
    """Classe Noeud pour représenter tout type d'objet dans les piles et files"""

    def __init__(self, donnee):
        """Initialise l'objet avec une donnée en paramètre

        Parameters:
            donnee (Any) : donnée que l'on souhaite associer au noeud
        """
        self.donnee = donnee
        self.precedent = None

    def get_donnee(self):
        """Retourne la donnée stockée dans le noeud

        Returns:
            (Any) : la donnée stockée dans le noeud
        """
        return self.donnee

    def set_donnee(self, data):
        """Modifie la donnée stockée dans le noeud

        Parameters:
            data (Any) : la donnée qui sera stockée dans le noeud
        """
        self.donnee = data

    def get_precedent(self):
        """Retourne le noeud précédent

        Returns:
            (Noeud) : le noeud précédant celui-ci
        """
        return self.precedent

    def set_precedent(self, noeud_precedent):
        """Modifie le noeud précédent

        Parameters:
            noeud_precedent (Noeud) : le noeud qui précédant le noeud actuel
        """
        self.precedent = noeud_precedent