import graphviz as gv
from copy import copy, deepcopy

# Permet de représenter graphiquement une instance d'arbre binaire.
# Le module doit être paramétré pour prendre en compte l'interface
# de la classe Arbre utilisée :
#      --> comment accéder au sous-arbre gauche ?
#      --> comment accéder au sous-arbre droit ?
#      --> comment accéder à l'étiquette ?
#      --> comment tester le cas de l'arbre vide ?
# Ce paramétrage s'effectue dans l'en-tête du module.
# Il faut également paramétrer si l'utilisation sera faite en notebook ou pas.

JUPYTER_NOTEBOOK = False

#en tête pour l'interface n°1 du notebook de documentation
#ACCES_VIA_GETTERS= False
#ACCES_E = "v"
#ACCES_G = "g"
#ACCES_D = "d"
#ARBRE_VIDE_IS_ARBRE = False
#ACCES_V = None

#en-tête pour l'interface n°2 du notebook de documentation
ACCES_VIA_GETTERS= True
ACCES_E = "get_etiquette"
ACCES_E2 = "get_etiquette2"
ACCES_G = "get_gauche"
ACCES_D = "get_droite"
ARBRE_VIDE_IS_ARBRE = False
ACCES_V = None


class VizuArbreB:
    def __init__(self, arbre, couleurs = None,
                              formes = None):
        '''
        - arbre : instance d'arbre binaire à représenter

        - etiquettes_secondaires [ = None] : dictionnaire ayant pour clefs des étiquettes
                                        de l'arbre et pour valeurs les étiquette secondaires
                                        à afficher.

        - couleurs [ = None] : dictionnaire ayant pour clefs des étiquettes de l'arbre et pour
                                        valeurs les couleurs personnalisées des noeuds au format
                                        (H, S, V) avec H, S, V de type float entre 0 et 1.

        - formes [ = None] : dictionnaire ayant pour clefs des étiquettes de l'arbre et pour valeurs les formes
                                 des noeuds ('rect', 'rectangle', 'folder', 'house', 'ellipse', 'egg',
                                 'triangle', 'diamond' [...]
                                 https://graphviz.org/doc/info/shapes.html
        '''
        self.arbre = arbre
        self.etiquettes_secondaires = ""
        self.couleurs = copy(couleurs)
        self.formes = copy(formes)
        self._initialiser_parametres_dessin()

        self._creer_objet_graphviz()

    def _initialiser_parametres_dessin(self):

        self.size = '10'                              #taille maximale de l'image générée
        self.label = 'Arbre Binaire'                  #titre du graphique
        self.moteur = 'dot'                           #moteur utilisé pour le placement des noeuds

        self.node_style = 'filled'                    #remplissage des noeuds
        self.node_shape = 'circle'                    #forme des noeuds
        self.node_fontsize = '12'                     #taille de la police des noeuds
        self.node_small_fontsize = '11'               #taille de la police secondaire des noeuds
        self.node_color = (0.5, 0.5, 1.0)             #couleur par défaut au format HSV
        self.node_width = '0.35'                      #largeur des noeuds
        self.node_height = '0.35'                     #hauteur des noeuds

        self.edge_style = 'solid'                     #flèches en traits pleins
        self.edge_arrowhead = 'empty'                 #forme des têtes de flèches
        self.edge_arrowsize = '0.5'                   #taille des têtes de flèches

    def _creer_objet_graphviz(self):
        self.G = gv.Digraph('arbre')
        self._injecter_parametres_dessin_dans_graphviz()
        self._dessiner_arbre(arbre = self.arbre, name = '')
        if JUPYTER_NOTEBOOK :
            display(self.G)
        else :
            self.G.render(view=True)

    def _injecter_parametres_dessin_dans_graphviz(self):

        self.G.attr(root = '',
                    size = self.size,
                    label = self.label,
                    engine = self.moteur)

        self.G.node_attr.update(style = self.node_style,
                                shape = self.node_shape,
                                fontsize = self.node_fontsize,
                                width = self.node_width,
                                height = self.node_height,
                                fixedsize = 'False',
                                margin = '0, 0')

        self.G.edge_attr.update(style = self.edge_style,
                                arrowhead = self.edge_arrowhead,
                                arrowsize = self.edge_arrowsize
                               )

############## METHODES D'ACCES POUR PARCOURIR L'ARBRE FOURNI #######

    def _tester_vide(self, arbre):
        if ARBRE_VIDE_IS_ARBRE :
            return getattr(arbre, ACCES_V)()
        else:
            return arbre is None

    def _donner_gauche(self, arbre):
        if ACCES_VIA_GETTERS :
            return getattr(arbre, ACCES_G)()
        else:
            return getattr(arbre, ACCES_G)

    def _donner_droite(self, arbre):
        if ACCES_VIA_GETTERS :
            return getattr(arbre, ACCES_D)()
        else:
            return getattr(arbre, ACCES_D)

    def _donner_etiquette(self, arbre):
        if ACCES_VIA_GETTERS :
            return getattr(arbre, ACCES_E)()
        else:
            return getattr(arbre, ACCES_E)

    def _donner_etiquette2(self, arbre):
        if ACCES_VIA_GETTERS :
            return getattr(arbre, ACCES_E2)()
        else:
            return getattr(arbre, ACCES_E2)

############## METHODES DE CREATION DES ATTRIBUTS GRAPHIQUES GRAPHVIZ #######

    def _tuple_to_string(couleur):
        return ' '.join([str(round(c, 4)) for c in couleur])

    def _donner_couleur(self, sommet):
        if self.couleurs == None or sommet not in self.couleurs:
            return VizuArbreB._tuple_to_string(self.node_color)
        else:
            return VizuArbreB._tuple_to_string(self.couleurs[sommet])

    def _donner_label(self, sommet,sommet2):
        e_princ = str(sommet)
        e_secon = str(sommet2)

        S='<'
        if e_princ!="" :
            if len(e_princ)==1 and ord(e_princ)==10:
                e_princ="RL"
            elif len(e_princ)==1 and ord(e_princ)==93:
                e_princ="CF"
            S = S+'<B>' + e_princ + '</B>'

        small = self.node_small_fontsize
        S = S+'<I><FONT POINT-SIZE="' + small + '"><BR/>' + e_secon + '</FONT></I>>'
        return S

    def _donner_forme(self, sommet):
        if self.formes == None or sommet not in self.formes:
            return self.node_shape
        else:
            return self.formes[sommet]

################  DESSIN ET ENREGISTREMENT ########################

    def _dessiner_arbre(self, arbre, name):
        if not self._tester_vide(arbre):
            self.G.node( name, label = str(self._donner_label(self._donner_etiquette(arbre),self._donner_etiquette2(arbre))),
                               color = self._donner_couleur(self._donner_etiquette(arbre)),
                               shape = self._donner_forme(self._donner_etiquette(arbre)))
            #print(str(self._donner_label(self._donner_etiquette(arbre),self._donner_etiquette2(arbre))))

            if name != '':
                self.G.edge(name[:-1], name)
            sag = self._donner_gauche(arbre)
            sad = self._donner_droite(arbre)
            self._dessiner_arbre(sag, name + '1')
            self._dessiner_arbre(sad, name + '0')



################  METHODES ACCESSIBLES     ########################

    def modifier(self, **kwargs):
        '''
        Une fois un graphique créé et représenté, permet de modifier les paramètres de dessin.

        - REINITIALISER LES PARAMETRES

            - reset  [ = False]             : booléen indiquant si on réinitialise les modifications
                                                   de paramètres déjà prises en compte auparavant

        - PARAMETRES DU GRAPHE EN ENTIER

            - size [ = 10  ]                : taille maximale de l'image générée

            - label [ = 'Arbre Binaire']    : titre du graphique

            - moteur [ = 'dot']             : moteur de placement des noeuds utilisé par graphviz.
                                                Autres choix : 'circo', 'dot', 'fdp', 'neato', 'osage',
                                                'patchwork', 'sfdp','twopi'
                                                https://graphviz.org/documentation/

        - PARAMETRES INDIVIDUELS DES NOEUDS

            - etiquettes_secondaires [ = None] : dictionnaire ayant pour clefs des étiquettes
                                                   de l'arbre et pour valeurs les étiquette secondaires
                                                   à afficher.

            - couleurs [ = None]               : dictionnaire ayant pour clefs des étiquettes de
                                                    l'arbre et pour valeurs les couleurs des noeuds
                                                    au format (H, S, V) avec H, S, V de type float
                                                    entre 0 et 1.

            - formes [ = None]                 : dictionnaire ayant pour clefs des étiquettes de
                                                   l'arbre et pour valeurs les formes des sommets ('rect',
                                                   'rectangle', 'folder', 'house', 'ellipse', 'egg',
                                                   'triangle', 'diamond' [...]
                                                   https://graphviz.org/doc/info/shapes.html

        - PARAMETRES DES NOEUDS PAR DEFAUT

            - node_shape [ = 'circle']        : forme des noeuds dessinés. Autres formes disponibles
                                                   rect, ellipse, folder, star [...].
                                                   https://graphviz.org/doc/info/shapes.html

            - node_width [ = 0.35]            : largeur des noeuds

            - node_height [ = 0.35]           : hauteur des noeuds

            - node_color [ = (0.5, 0.2, 1)]   : couleur des noeuds au format HSV

            - node_fontsize [ = 12]           : taille de police de l'étiquette principale des noeuds

            - node_small_fontsize [ = 11]     : taille de police de l'étiquette secondaire des noeuds

            - node_style [ = 'filled']        : style de remplissage. Au choix parmi 'solid', 'dashed',
                                                   'dotted', 'bold', 'rounded', 'filled' [...]
                                                   https://graphviz.org/doc/info/attrs.html#k:style

        - PARAMETRES DES ARCS PAR DEFAUT

            - edge_style [ = 'solid']         : style du tracé, au choix parmi 'solid', 'dashed',
                                                   'dotted', 'bold'

            - edge_arrowhead [= 'empty']      : forme de la tête de la flèche. Au choix parmi 'normal',
                                                   'none', 'invempty', 'open' [...]
                                                   https://graphviz.org/doc/info/attrs.html#k:arrowType

            - edge_arrowsize [= 0.5]          : taille de la tête de la flèche
        '''

        legal_args = ("size", "label", "node_style", "node_shape", "node_fontsize",
                      "node_small_fontsize","node_color", "node_width", "node_height",
                      "edge_style", "edge_arrowhead", "edge_arrowsize", "reset", "moteur",
                      "etiquettes_secondaires", "couleurs", "formes")

        if "reset" in kwargs.keys():
            if kwargs["reset"] == 'True':
                self._initialiser_parametres_dessin()
                self.etiquettes_secondaires = None
                self.couleurs = None
                self.formes = None
        for key, val in kwargs.items():
            if key in legal_args:
                if type(val) == int or type(val) == float:
                    setattr(self, key, str(val))
                elif type(val) == dict:
                    setattr(self, key, deepcopy(val))
                else:
                    setattr(self, key, val)
        self._creer_objet_graphviz()

    def enregistrer(self, nom_fichier = None, format_image = None):
        '''
         Permet d'enregistrer le graphe au format texte 'graphviz' et au format image choisi.
         Il y a donc deux fichiers qui sont générés.

          - nom_fichier [ = 'mon_arbre_binaire'] : nom des deux fichiers sauvegardés dont l'un sera
                                                   suffixé avec l'extension correspondant au format image choisi


          - format_image [ = 'png']              : format de fichier de l'image générée. Au choix parmi :
                                                   'ps', 'eps', 'svg', 'jpg', 'tiff' [...]
                                                   https://graphviz.org/doc/info/output.html
        '''
        if nom_fichier == None:
            nom_fichier = self.nom_fichier
        if format_image == None:
            format_image = self.format_image
        self.G.render(filename = nom_fichier, format = format_image)
