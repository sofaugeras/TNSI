﻿from vizu_arbreb import VizuArbreB

class Noeud:
    def __init__(self,cle,freq,gauche=None,droit=None):
        self.etiquette = cle
        self.etiquette2 = freq
        self.brancheg=gauche
        self.branched=droit


class Arbre:
    def __init__(self,cle="",freq="",arbreg=None,arbred=None):
        if cle=="" and freq=="":
            self.noeud=None
        else:
            self.noeud=Noeud(cle,freq,arbreg,arbred)

    def est_vide(self):
        return self.noeud is None

    def get_etiquette(self):
        assert not self.est_vide()
        return self.noeud.etiquette

    def get_etiquette2(self):
        assert not self.est_vide()
        return self.noeud.etiquette2

    def get_gauche(self):
        return self.noeud.brancheg

    def get_droite(self):
        return self.noeud.branched

    def est_feuille(self):
        return self.noeud.brancheg is None and self.noeud.branched is None

    def __repr__(self):
        return (self.get_etiquette())





feuille1 = Arbre("feuille1","",None,None)
feuille2 = Arbre("feuille2","",None,None)
mon_arbre = Arbre("racine","",feuille1,feuille2)
tab=[feuille1,feuille2,mon_arbre]


#v = VizuArbreB(mon_arbre)



assert str(tab)=="[feuille1, feuille2, racine]","mauvaises valeurs de tableau"