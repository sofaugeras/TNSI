﻿from arbre import *

##fonction frequences
##Objetif : déterminer les fréquences d'apparition de chaque caractère d'une chaine de caractere
##entrée : texte, chaine de caractère
##valeur renvoyée : dictionnaire
def frequences (texte):

    pass

# fonction creer_feuilles
# objectif :p créer un tableau contenant les arbres élémentaire triés par ordre croissant de fréquence
#entrée : dictionnaires des fréquences associées aux caractères
# valeur de retour : tableau trié
def creer_feuilles(dico):
    pass


## procedure inserer
##détermine à quelle position de la liste sdoit on insérer un noeud pour que les noeud soit triés dans
##   le tableau por ordre croissant des fréquence, puis insère le noeud dans cette position
## entrée :  tab, tableau contenant des arbres
## arbre : arbre à insérer
def inserer(tab,arbre):

    pass



#fonction creer_arbre
#objectif : créer un arbre de huffman à partir d'un tableau trié d'arbre élémentaire
#entrée : tableau trié
#valeur de retour : arbre total
def creer_arbre(tab_noeud):
    pass


# procedure code_binaire
#
# entrée :
#
def code_binaire(arbre,dico,code=""):
    if  arbre.est_feuille() :
        dico[arbre.get_etiquette()]=code
    else :
        code_binaire(arbre.get_gauche(),dico,code+"0")
        code_binaire(arbre.get_droite(),dico,code+"1")

# fonction compresser
# détermine le codage binaire d'un texte entier à partir d'un dictionnaire de correspondance
# entrée : texte, chaine de caratères contenant le texte à compresser
#           dico, dictionnaire de correspondance entre clé et code binaire
# valeur de retour, code binaire sous forme d'une chaine de caractère
def compresser(texte,dico):
    pass

# fonction decompresser
# détermine le texye initial à partir d'un codage binaire
# entrée : code, chaine de caratères contenant le codage binaire d'un texte compressé
#           arbre, arbre de huffman qui a permis de compresser le texte initial
# valeur de retour, texte initial décompressé
def decoder(code,arbre):
    pass

## Tests des fonctions pour le codage de huffman
#dico=frequences ("anticonstitutionnellement")
#tab_feuilles=creer_feuilles(dico)


#arbre_huffman=creer_arbre(tab_feuilles)
#VizuArbreB(arbre_huffman)
#dico_corresp = {}
#code_binaire(arbre_huffman,dico_corresp)
#code = compresser("anticonstitutionnellement",dico_corresp)

