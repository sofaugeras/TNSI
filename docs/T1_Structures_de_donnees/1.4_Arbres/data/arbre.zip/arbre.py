from File import File
from pile import Pile

class ArbreB:
    def __init__(self, valeur, gauche = None, droit = None):
        """
        Constructeur d'un arbre binaire
        @param valeur: la valeur du noeud
        @param gauche: le sous-arbre gauche, par défaut None
        @param droit: le sous-arbre droit, par défaut None
        exemple:
        A=ArbreB('a', ArbreB('b', ArbreB('d'), ArbreB('e')), ArbreB('c', ArbreB('f'), ArbreB('g')))
        """
        self.noeud = valeur
        self.gauche = gauche
        self.droit = droit
        
    def __repr__(self):
        """
        Affichage de l'arbre, redéfinition de la méthode print()
        @return: l'arbre sous forme de chaîne de caractères
        exemple: print(A)
        """
        return str(self.noeud) +str(self.gauche).replace('None','.')+str(self.droit).replace('None','.')
    
    def affiche(self, indent = 0):
        """Affiche l'arbre en utilisant un parcours préfixe, simule un affichage hiérachique de l'arbre
        @param indent: indentation pour l'affichage
        @return: l'arbre sous forme de chaîne de caractères
        """
        
        val = self.noeud
        s = ' '*2*indent + '|' + '_' + str(val) + '\n'
        if self.gauche is not None:
            s += self.gauche.affiche(indent + 1)
        if self.gauche is None and self.droit is not None:
            s += ' '*(2*indent+2) + '|' + '_' + 'None' + '\n'     

        if self.droit is not None:
            s += self.droit.affiche(indent + 1)
        if self.droit is None and self.gauche is not None:
            s += ' '*(2*indent+2) + '|' + '_' + 'None' + '\n'  
        return s
    
    
    def est_Vide(self):
        """"
        retourne True si l'arbre est vide
        @param: l'arbre à tester
        @return: True si l'arbre est vide, False sinon
        """
        return self.noeud is None
    
   
    def estFeuille(self):
        """"
        retourne True si l'arbre est une feuille
        @param: l'arbre à tester
        @return: True si l'arbre est une feuille, False sinon
        """
        return self.gauche is None and self.droit is None and self.noeud is not None
    
    def taille(self):
        """
        retourne la taille de l'arbre
        @param: l'arbre à tester    
        @return: la taille de l'arbre
        """
        # condition d'arrêt
        if self.est_Vide():
            return 0
        # Appel récursif
        # Initialisation des variables pour stocker la taille des sous-arbres
        # Permet de tester si le sous-arbre est vide ou non        
        taille_gauche = 0
        taille_droite = 0
        # Appel récursif sur les sous-arbres
        # On teste si le sous-arbre est vide ou non
        if not self.gauche is None:
            taille_gauche = self.gauche.taille()
            
        if not self.droit is None :
            taille_droite = self.droit.taille()
        # On retourne la taille de l'arbre courant 1 et on ajoute les tailles des sous-arbres
        return 1 + taille_gauche + taille_droite
    
    def taille2(self):
        """
        retourne la taille de l'arbre
        @param: l'arbre à tester    
        @return: la taille de l'arbre
        """
        if self.est_Vide():
            return 0
        return 1 + self.gauche.taille() + self.droit.taille()
    
    def nb_feuilles(self):
        """
        retourne le nombre de feuilles de l'arbre
        @param: l'arbre à tester
        @return: le nombre de feuilles de l'arbre
        """
        if self.est_Vide():
            return 0
        if self.estFeuille():
            return 1
        nb_feuilles_gauche = 0
        nb_feuilles_droite = 0
        if not self.gauche is None:
            nb_feuilles_gauche = self.gauche.nb_feuilles()
        if not self.droit is None:
            nb_feuilles_droite = self.droit.nb_feuilles()
        return nb_feuilles_gauche + nb_feuilles_droite
    
    def nb_feuilles2(self):
        """
        retourne le nombre de feuilles de l'arbre
        @param: l'arbre à tester
        @return: le nombre de feuilles de l'arbre
        """
        if self is None:
            return 0
        # Condition d'arrêt : le noeud est une feuille
        if (self.gauche is None) and (self.droit is None):
            return 1
        # Appel récursif : on somme les feuilles des sous-arbres
        return self.gauche.nb_feuilles() +  self.droit.nb_feuilles()

    def hauteur(self):
        """retourne la hauteur de l'arbre
        @param: l'arbre à tester
        @return: la hauteur de l'arbre
        """
        # Initialisation des variables pour stocker la hauteur des sous-arbres
        hauteur_gauche = 0
        hauteur_droite = 0
        # Condition d'arrêt : l'arbre est vide
        if self.est_Vide():
            return 0
        # Appel récursif sur les sous-arbres, si ils ne sont pas vide
        if not self.gauche is None:
            hauteur_gauche = self.gauche.hauteur()
        if not self.droit is None : 
            hauteur_droite = self.droit.hauteur()
        # On retourne la hauteur de l'arbre courant 1 + la hauteur du sous-arbre le plus haut
        return 1 + max( hauteur_gauche, hauteur_droite)
    
    def parcoursPrefixe(self):
        """parcours préfixe
        @param: l'arbre à parcourir
        @return: la liste des noeuds dans l'ordre préfixe
        """
        # Condition d'arrêt, si l'arbre est vide on renvoie une liste vide
        if self.noeud is None:
            return []
        # Appel récursif et retourne la réponse
        # Initialisation des listes pour stocker les valeurs des sous-arbres
        liste_gauche = []
        liste_droite = []
        # Appel récursif sur les sous-arbres, si ils ne sont pas vide
        if not self.gauche is None:
            liste_gauche = self.gauche.parcoursPrefixe()
        if not self.droit is None:
            liste_droite = self.droit.parcoursPrefixe()
        # La valeur est insérée AVANT les appels des sous-arbres Gauche et Droit
        return [self.noeud] + liste_gauche + liste_droite

    def parcoursPrefixe2(self):
        """parcours préfixe
        @param: l'arbre à parcourir
        @return: la liste des noeuds dans l'ordre préfixe
        """
        if self.est_Vide():
            return []
        return [self.noeud] + self.gauche.parcoursPrefixe() + self.droit.parcoursPrefixe()
    
    def parcoursInfixe(self):
        """parcours infixe
        @param: l'arbre à parcourir
        @return: la liste des noeuds dans l'ordre infixe
        """
        # Condition d'arrêt
        if self.noeud is None:
            return []
        # Appel récursif et retourne la réponse
        # La valeur est insérée AVANT les appels
        liste_gauche = []
        liste_droite = []
        if not self.gauche is None:
            liste_gauche = self.gauche.parcoursInfixe()
        if not self.droit is None:
            liste_droite = self.droit.parcoursInfixe()
        return [] + liste_gauche + [self.noeud] + liste_droite
    
    def parcoursSuffixe(self):
        """
        Description: parcours suffixe
        @param: l'arbre à parcourir
        @return: la liste des noeuds dans l'ordre suffixe
        """
        # Condition d'arrêt
        if self.noeud is None:
            return []
        # Appel récursif et retourne la réponse
        # La valeur est insérée AVANT les appels
        liste_gauche = []
        liste_droite = []
        if not self.gauche is None:
            liste_gauche = self.gauche.parcoursSuffixe()
        if not self.droit is None:
            liste_droite = self.droit.parcoursSuffixe()
        return [] + liste_gauche + liste_droite  + [self.noeud]
    

    def infixe_avec_liste(self):
            """parcours infixe avec une liste en utilisant le paradigme impératif
            utilisant d'une pile pour empiler les noeuds à traiter
            @param: l'arbre à parcourir
            @return: la liste des noeuds dans l'ordre infixe
            """
            parcours = []
            pile = []

            current = self

            while pile != [] or current is not None:
                if current is not None:
                    pile.append(current)
                    current = current.gauche
                else:
                    current = pile.pop()
                    parcours.append(current.noeud)
                    current = current.droit

            return parcours
        
    
    def recherche(self, valeur):
        """retourne True si la valeur est dans l'arbre
        @param: l'arbre à parcourir
        @param: la valeur à rechercher
        @return: True si la valeur est dans l'arbre, False sinon
        """
        if self is None:
            return False
        if self.noeud ==  valeur:
            return True
        TrouveGauche = False
        TrouveDroit = False
        if not self.gauche is None:
            TrouveGauche = self.gauche.recherche(valeur)
        if not self.droit is None:
            TrouveDroit = self.droit.recherche(valeur)
        return TrouveGauche or TrouveDroit
    
    def parcoursLargeur(self):
        """parcours en largeur
        @param: l'arbre à parcourir
        @return: la liste des noeuds dans l'ordre en largeur
        """
        #Initialisation d'une file vide pour stocker les éléments à traiter
        f=File()
        #Mettre le noeud source
        f.enfile(self)
        #Liste des sommets pour restituer le parcours en largeur
        l=[]
        #Tant quee la file n'est pas vide
        while not f.estFileVide():
            # on dépile le noeud du début de la file pour le traiter
            a=f.defile()
            l.append(a.noeud)
            if not a.gauche is None:
                #f.insert(0,a.gauche)
                f.enfile(a.gauche)
            if not a.droit is None:
                #f.insert(0,a.droit)
                f.enfile(a.droit)
        return l
    
